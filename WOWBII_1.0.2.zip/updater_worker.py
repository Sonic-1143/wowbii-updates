#!/usr/bin/env python3
"""Detached WOWBII updater worker: wait for server exit, install, and restart."""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


def process_exists(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def write_status(root, state, message, version=None):
    folder = root / "updates"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / "worker_status.json"
    temp = target.with_suffix(".json.tmp")
    payload = {
        "state": state,
        "message": message,
        "version": version,
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with temp.open("w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=2)
        stream.write("\\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(str(temp), str(target))


def log_message(path, message):
    with path.open("a", encoding="utf-8") as stream:
        stream.write("\\n[" + time.strftime("%Y-%m-%d %H:%M:%S") + "] " + message + "\\n")
        stream.flush()


def restart_server(root):
    if os.name == "nt":
        # `start` treats its first quoted argument as the window title.
        command = 'start "" "' + str(root / "run_server.bat") + '"'
        subprocess.Popen(["cmd.exe", "/c", command], cwd=str(root),
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, close_fds=True)
    else:
        subprocess.Popen([sys.executable, str(root / "server.py")], cwd=str(root),
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    log_dir = root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "updater_worker.log"
    staged_meta = root / "updates" / "staged_manifest.json"
    version = None
    try:
        if staged_meta.is_file():
            try:
                version = json.loads(staged_meta.read_text(encoding="utf-8")).get("version")
            except Exception:
                pass
        write_status(root, "waiting_for_server", "Waiting for the current server process to stop.", version)
        deadline = time.time() + 120
        while process_exists(args.pid) and time.time() < deadline:
            time.sleep(0.5)
        if process_exists(args.pid):
            message = "Timed out waiting for the server to stop; no second server was started."
            log_message(log_path, message)
            write_status(root, "failed", message, version)
            raise SystemExit(2)

        result = None
        staged_requirements = root / "updates" / "staged" / "requirements.txt"
        if staged_requirements.is_file():
            write_status(root, "installing_dependencies", "Preparing updated Python dependencies.", version)
            dependency_result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(staged_requirements)],
                cwd=str(root), capture_output=True, text=True
            )
            log_message(log_path, "Dependency preflight exit code: " + str(dependency_result.returncode))
            log_message(log_path, dependency_result.stdout or "")
            log_message(log_path, dependency_result.stderr or "")
            if dependency_result.returncode:
                result = dependency_result

        if result is None:
            write_status(root, "installing_files", "Applying the verified update with rollback protection.", version)
            result = subprocess.run([sys.executable, str(root / "apply_update.py")],
                                    cwd=str(root), capture_output=True, text=True)
        log_message(log_path, "Installer exit code: " + str(result.returncode))
        log_message(log_path, result.stdout or "")
        log_message(log_path, result.stderr or "")

        if result.returncode:
            # apply_update rolls back before returning failure. Startup recovery is a second safety net.
            write_status(root, "restarting_previous", "Update failed; restarting the previous version.", version)
        else:
            write_status(root, "restarting", "Update installed; restarting WOWBII.", version)
        restart_server(root)
        write_status(root, "restart_requested", "Server restart was launched. Reconnect to the teacher dashboard.", version)
    except SystemExit:
        raise
    except Exception as exc:
        log_message(log_path, "WORKER ERROR: " + repr(exc))
        write_status(root, "failed", "Updater worker failed: " + str(exc), version)
        raise


if __name__ == "__main__":
    main()
