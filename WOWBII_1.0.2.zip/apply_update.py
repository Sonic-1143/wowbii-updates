#!/usr/bin/env python3
"""Crash-conscious WOWBII staged update installer with verified rollback."""
import hashlib, hmac, json, os, re, shutil, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGE = ROOT / "updates" / "staged"
META = ROOT / "updates" / "staged_manifest.json"
ALLOW = re.compile(r"^(server\.py|apply_update\.py|updater_worker\.py|requirements\.txt|templates/[A-Za-z0-9_.-]+\.html)$")

def _safe_target(name):
    if not isinstance(name, str) or not ALLOW.fullmatch(name) or "\\" in name or ".." in Path(name).parts:
        raise ValueError("Unsafe staged path: " + str(name))
    target = (ROOT / name).resolve()
    if ROOT.resolve() not in target.parents:
        raise ValueError("Update path escapes project root: " + name)
    return target

def _write_journal(path, journal):
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(journal, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(str(temp), str(path))

def load_payloads():
    if not META.is_file():
        raise ValueError("No staged update found. Download and verify an update first.")
    meta = json.loads(META.read_text(encoding="utf-8"))
    names = meta.get("files")
    hashes = meta.get("file_hashes")
    if (not isinstance(names, list) or not names or
            any(not isinstance(name, str) for name in names) or
            len(names) != len(set(names)) or
            not isinstance(hashes, dict) or set(names) != set(hashes)):
        raise ValueError("Staged manifest is incomplete, duplicated, or invalid.")
    payloads = {}
    for name in names:
        _safe_target(name)
        src = (STAGE / name).resolve()
        if STAGE.resolve() not in src.parents or not src.is_file():
            raise ValueError("Missing or unsafe staged file: " + name)
        payload = src.read_bytes()
        expected = str(hashes[name]).lower()
        if not re.fullmatch(r"[a-f0-9]{64}", expected) or not hmac.compare_digest(hashlib.sha256(payload).hexdigest(), expected):
            raise ValueError("Staged file integrity check failed: " + name)
        payloads[name] = payload
    return meta, payloads

def apply_update(root=ROOT):
    global ROOT, STAGE, META
    ROOT = Path(root).resolve()
    STAGE = ROOT / "updates" / "staged"
    META = ROOT / "updates" / "staged_manifest.json"
    meta, payloads = load_payloads()
    version = str(meta.get("version", "")).strip()
    if not re.fullmatch(r"\d+(?:\.\d+){1,3}", version):
        raise ValueError("Staged update version is invalid.")
    version_file = ROOT / "APP_VERSION"
    old_version = version_file.read_text(encoding="utf-8").strip() if version_file.exists() else "0.0.0"
    def vtuple(v): return tuple(int(x) for x in v.split("."))
    if vtuple(version) <= vtuple(old_version):
        raise ValueError("Staged version must be newer than the installed version.")
    stamp = time.strftime("%Y%m%d_%H%M%S") + f"_{time.time_ns() % 1_000_000_000:09d}"
    backup = ROOT / "backups" / ("pre_update_" + stamp)
    backup.mkdir(parents=True, exist_ok=False)
    # Back up all targets and the version marker before touching any live file.
    prior = {}
    for name in payloads:
        target = _safe_target(name)
        exists = target.is_file()
        prior[name] = exists
        if exists:
            dest = backup / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, dest)
    if version_file.exists():
        shutil.copy2(version_file, backup / "APP_VERSION")
    journal = {"version": version, "files": prior, "old_version": old_version,
               "version_existed": version_file.exists(), "state": "installing"}
    _write_journal(backup / "rollback_journal.json", journal)
    try:
        for name, data in payloads.items():
            target = _safe_target(name)
            target.parent.mkdir(parents=True, exist_ok=True)
            temp = target.with_name(target.name + ".wowbii_tmp")
            with temp.open("wb") as stream:
                stream.write(data); stream.flush(); os.fsync(stream.fileno())
            os.replace(str(temp), str(target))
        temp_version = version_file.with_name("APP_VERSION.wowbii_tmp")
        with temp_version.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(version + "\n"); stream.flush(); os.fsync(stream.fileno())
        os.replace(str(temp_version), str(version_file))
        journal["state"] = "committed"
        _write_journal(backup / "rollback_journal.json", journal)
    except BaseException:
        # Restore every original target; delete files that did not exist before.
        errors = []
        for name, existed in reversed(list(prior.items())):
            target = _safe_target(name)
            try:
                if existed:
                    saved = backup / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    restore_tmp = target.with_name(target.name + ".rollback_tmp")
                    shutil.copy2(saved, restore_tmp)
                    os.replace(str(restore_tmp), str(target))
                else:
                    try: target.unlink()
                    except FileNotFoundError: pass
            except Exception as exc:
                errors.append(name + ": " + str(exc))
        try:
            saved_version = backup / "APP_VERSION"
            if saved_version.exists():
                shutil.copy2(saved_version, version_file)
            else:
                try: version_file.unlink()
                except FileNotFoundError: pass
        except Exception as exc:
            errors.append("APP_VERSION: " + str(exc))
        journal["state"] = "rollback_failed" if errors else "rolled_back"
        journal["rollback_errors"] = errors
        _write_journal(backup / "rollback_journal.json", journal)
        if errors:
            raise RuntimeError("Installation failed and rollback needs manual attention: " + "; ".join(errors))
        raise
    return backup, version


def recover_incomplete_updates(root=ROOT):
    """Roll back a transaction interrupted by power loss or worker termination."""
    root = Path(root).resolve()
    backup_root = root / "backups"
    if not backup_root.is_dir():
        return []
    recovered = []
    for backup in sorted((p for p in backup_root.glob("pre_update_*") if p.is_dir()), reverse=True):
        journal_path = backup / "rollback_journal.json"
        if not journal_path.is_file():
            continue
        journal = None
        try:
            journal = json.loads(journal_path.read_text(encoding="utf-8"))
            if journal.get("state") not in {"installing", "rollback_failed", "recovery_required"}:
                continue
            files = journal.get("files", {})
            if not isinstance(files, dict):
                raise ValueError("Recovery journal file map is invalid.")
            for name, existed in reversed(list(files.items())):
                if (not isinstance(name, str) or not ALLOW.fullmatch(name) or
                        "\\" in name or ".." in Path(name).parts or
                        not isinstance(existed, bool)):
                    raise ValueError("Unsafe path in recovery journal: " + str(name))
                target = (root / name).resolve()
                if root not in target.parents:
                    raise ValueError("Recovery path escapes project root.")
                if existed:
                    saved = backup / name
                    if not saved.is_file():
                        raise ValueError("Missing recovery backup for " + name)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    temp = target.with_name(target.name + ".recovery_tmp")
                    shutil.copy2(saved, temp)
                    os.replace(str(temp), str(target))
                else:
                    try: target.unlink()
                    except FileNotFoundError: pass
            version_file = root / "APP_VERSION"
            if journal.get("version_existed"):
                saved_version = backup / "APP_VERSION"
                if not saved_version.is_file():
                    raise ValueError("Missing APP_VERSION recovery backup.")
                version_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved_version, version_file)
            else:
                try: version_file.unlink()
                except FileNotFoundError: pass
            journal["state"] = "recovered_after_interruption"
            _write_journal(journal_path, journal)
            recovered.append(backup.name)
        except Exception as exc:
            if isinstance(journal, dict):
                journal["state"] = "recovery_required"
                journal["recovery_error"] = str(exc)
                _write_journal(journal_path, journal)
            raise RuntimeError("Automatic update recovery failed in " + backup.name + ": " + str(exc))
    return recovered

def main():
    backup, version = apply_update()
    print("Update", version, "installed successfully.")
    print("Backup:", backup)
    print("Restarting is handled by updater_worker.py.")
if __name__ == "__main__":
    try: main()
    except Exception as exc:
        print("UPDATE FAILED:", exc)
        sys.exit(1)
