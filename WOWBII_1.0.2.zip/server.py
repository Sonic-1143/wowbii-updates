from flask import Flask, request, jsonify, render_template, session
from flask_socketio import SocketIO
from pathlib import Path
import json, random, time, threading, secrets, os, hmac, re, sqlite3, csv, io, hashlib, unicodedata, ipaddress, logging, zipfile, shutil, urllib.request, urllib.parse
from logging.handlers import RotatingFileHandler

ROOT = Path(__file__).resolve().parent
# Recover any update transaction interrupted by power loss before normal startup.
try:
    from apply_update import recover_incomplete_updates
    _recovered_updates = recover_incomplete_updates(ROOT)
    if _recovered_updates:
        print("Recovered interrupted update transaction(s):", ", ".join(_recovered_updates))
except Exception as _recovery_error:
    raise RuntimeError("WOWBII update recovery must be resolved before startup: " + str(_recovery_error))
BANK_FILE = ROOT / "questions.json"
DB_FILE = Path(os.environ.get("QUIZ_DB_PATH", str(ROOT / "quiz_history.sqlite3")))
app = Flask(__name__)
# Keep the Flask signing key stable across restarts so teacher sessions/cookies
# are not invalidated by an ordinary server restart.
SECRET_FILE = ROOT / ".quiz_secret"
def load_secret_key():
    try:
        value = SECRET_FILE.read_text(encoding="utf-8").strip()
        if len(value) >= 48:
            return value
    except OSError:
        pass
    value = secrets.token_hex(32)
    try:
        SECRET_FILE.write_text(value, encoding="utf-8")
        try: SECRET_FILE.chmod(0o600)
        except OSError: pass
    except OSError:
        app.logger.exception("Could not persist Flask secret key; sessions may reset after restart")
    return value
app.secret_key = load_secret_key()
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["MAX_CONTENT_LENGTH"] = 30 * 1024 * 1024
LOG_FILE = ROOT / "logs" / "wowbii_server.log"
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
_file_handler = RotatingFileHandler(LOG_FILE, maxBytes=2_000_000, backupCount=4, encoding="utf-8")
_file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
app.logger.addHandler(_file_handler)
app.logger.setLevel(logging.INFO)
SERVER_STARTED_AT = time.time()
socketio = SocketIO(app, async_mode="threading", cors_allowed_origins=None, ping_interval=25, ping_timeout=60)
TEACHER_PIN_FILE = ROOT / ".teacher_pin"
def load_teacher_pin():
    try:
        value = TEACHER_PIN_FILE.read_text(encoding="utf-8").strip()
        if re.fullmatch(r"[0-9]{8,12}", value):
            return value
    except OSError:
        pass
    value = str(secrets.randbelow(90000000) + 10000000)
    try:
        TEACHER_PIN_FILE.write_text(value + "\n", encoding="utf-8")
        try: TEACHER_PIN_FILE.chmod(0o600)
        except OSError: pass
    except OSError:
        app.logger.exception("Could not persist teacher PIN; a new PIN may be generated on restart")
    return value
TEACHER_PIN = load_teacher_pin()
lock = threading.RLock()
security_lock = threading.RLock()
security_state = {"lockdown": False, "reason": "", "since": None, "blocked_ips": {}, "request_windows": {}, "unauthorized_windows": {}, "events": []}
LOCKDOWN_STUDENT_PATHS = {"/", "/api/join", "/api/status", "/api/answer", "/api/submit", "/api/leaderboard"}
SUSPICIOUS_PATHS = ("/.env", "/wp-admin", "/wp-login", "/phpmyadmin", "/.git", "/server-status", "/cgi-bin")
MAX_PLAYERS = 4
state = {"active": False, "pin": "2468", "class_level": 4, "subject": "Mathematics",
         "duration": 600, "start": None, "questions": [], "players": {}, "finished": False,
         "rapid_fire": False, "show_mode": True, "mode": "same", "competition": "individual", "title": "Primary School Quiz Challenge",
         "team_names": ["Team A", "Team B"], "created": None, "history_saved": False, "history_id": None,
         "tournament_enabled": True, "stages": [], "stage_index": 0, "round_type": "standard", "eliminated_players": [], "stage_history": [], "selected_category": ""}

PERSISTED_STATE_KEYS = (
    "active", "pin", "class_level", "subject", "duration", "start", "questions",
    "players", "finished", "mode", "competition", "title", "team_names", "created",
    "history_saved", "history_id", "question_count", "rapid_fire", "show_mode",
    "tournament_enabled", "stages", "stage_index", "round_type", "eliminated_players", "stage_history", "selected_category"
)

def db_connect():
    conn = sqlite3.connect(DB_FILE, timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    DB_FILE.parent.mkdir(parents=True, exist_ok=True)
    with db_connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS competition_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            finished_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            title TEXT NOT NULL, class_level INTEGER NOT NULL, subject TEXT NOT NULL,
            competition_mode TEXT NOT NULL, question_mode TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL, question_count INTEGER NOT NULL,
            results_json TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS runtime_state (
            singleton_id INTEGER PRIMARY KEY CHECK(singleton_id = 1),
            state_json TEXT NOT NULL,
            saved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS question_bank (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_level INTEGER NOT NULL CHECK(class_level BETWEEN 1 AND 6),
            subject TEXT NOT NULL,
            question TEXT NOT NULL,
            options_json TEXT NOT NULL,
            fingerprint TEXT NOT NULL UNIQUE,
            source_name TEXT NOT NULL DEFAULT 'manual/seed',
            category TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS question_answer_keys (
            question_id INTEGER PRIMARY KEY REFERENCES question_bank(id) ON DELETE CASCADE,
            answer_index INTEGER NOT NULL CHECK(answer_index BETWEEN 0 AND 3),
            explanation TEXT NOT NULL DEFAULT ''
        )""")
        # Migrate databases created by earlier app versions.
        columns = {r[1] for r in conn.execute("PRAGMA table_info(question_bank)")}
        if "category" not in columns:
            conn.execute("ALTER TABLE question_bank ADD COLUMN category TEXT NOT NULL DEFAULT ''")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_question_bank_filter ON question_bank(class_level, subject)")
        conn.execute("""CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            ip_address TEXT NOT NULL, event_type TEXT NOT NULL, details TEXT NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS security_control (
            control_key TEXT PRIMARY KEY, control_value TEXT NOT NULL)""")
        saved_lockdown = conn.execute("SELECT control_value FROM security_control WHERE control_key='lockdown'").fetchone()
        if saved_lockdown:
            try:
                saved = json.loads(saved_lockdown[0])
                security_state.update({"lockdown": bool(saved.get("enabled")), "reason": str(saved.get("reason", "")), "since": saved.get("since")})
            except (ValueError, TypeError):
                pass
        conn.execute("""CREATE TABLE IF NOT EXISTS question_import_batches (
            id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL,
            imported_count INTEGER NOT NULL DEFAULT 0, skipped_count INTEGER NOT NULL DEFAULT 0,
            invalid_count INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            rolled_back INTEGER NOT NULL DEFAULT 0)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS question_import_batch_items (
            batch_id INTEGER NOT NULL REFERENCES question_import_batches(id) ON DELETE CASCADE,
            question_id INTEGER NOT NULL, PRIMARY KEY(batch_id, question_id))""")
        # One-time migration: seed the database from the bundled question bank only when empty.
        count = conn.execute("SELECT COUNT(*) FROM question_bank").fetchone()[0]
        if count == 0:
            try:
                seed = json.loads(BANK_FILE.read_text(encoding='utf-8'))
            except (OSError, json.JSONDecodeError):
                seed = []
            for q in seed if isinstance(seed, list) else []:
                normalized = normalize_question(q)
                if normalized:
                    insert_question(conn, normalized, 'bundled questions.json')


def persist_runtime_state():
    """Save active competition state so a server restart does not silently erase a session."""
    snapshot = {key: state.get(key) for key in PERSISTED_STATE_KEYS}
    try:
        with db_connect() as conn:
            conn.execute(
                "INSERT INTO runtime_state(singleton_id,state_json,saved_at) VALUES(1,?,CURRENT_TIMESTAMP) "
                "ON CONFLICT(singleton_id) DO UPDATE SET state_json=excluded.state_json,saved_at=CURRENT_TIMESTAMP",
                (json.dumps(snapshot, ensure_ascii=False),))
    except (sqlite3.Error, OSError, TypeError):
        app.logger.exception("Could not persist active competition state")


def restore_runtime_state():
    """Restore the last saved session; elapsed wall-clock time still counts against its timer."""
    try:
        with db_connect() as conn:
            row = conn.execute("SELECT state_json FROM runtime_state WHERE singleton_id=1").fetchone()
        if not row:
            return
        snapshot = json.loads(row["state_json"])
        if not isinstance(snapshot, dict):
            return
        for key in PERSISTED_STATE_KEYS:
            if key in snapshot:
                state[key] = snapshot[key]
        # Validate the recovered shape before exposing it to request handlers.
        if not isinstance(state.get("players"), dict) or not isinstance(state.get("questions"), list):
            raise ValueError("Invalid saved competition state")
        if state.get("start") is not None and remaining() <= 0 and not state.get("finished"):
            state["finished"] = True
            save_final_results()
            persist_runtime_state()
    except (sqlite3.Error, OSError, ValueError, TypeError, json.JSONDecodeError):
        app.logger.exception("Saved competition state could not be restored; starting safely")


def save_final_results():
    """Persist a finished competition once; the live session itself remains in memory."""
    if state.get("history_saved") or not state.get("active") or not state.get("finished"):
        return
    try:
        results = rows()
        board = leaderboard()
        snapshot = {"players": results, "leaderboard": board, "teams": state.get("team_names", []),
                    "stage": (state.get("stages") or [{"name":"Practice Round"}])[state.get("stage_index", 0)],
                    "stage_index": state.get("stage_index", 0), "stage_history": state.get("stage_history", [])}
        with db_connect() as conn:
            cur = conn.execute(
                "INSERT INTO competition_history(title,class_level,subject,competition_mode,question_mode,duration_seconds,question_count,results_json) VALUES(?,?,?,?,?,?,?,?)",
                (state["title"], state["class_level"], state["subject"], state["competition"],
                 state["mode"], state["duration"], state.get("question_count", len(state["questions"])),
                 json.dumps(snapshot, ensure_ascii=False)))
        state["history_saved"] = True
        state["history_id"] = cur.lastrowid
    except (sqlite3.Error, OSError, TypeError) as exc:
        app.logger.exception("Could not save competition history: %s", exc)


def normalize_question(q):
    """Normalize supported JSON/CSV/Excel question rows into a strict internal schema."""
    if not isinstance(q, dict):
        return None
    def first(*keys):
        for key in keys:
            if key in q and q[key] is not None and str(q[key]).strip() != "":
                return q[key]
        return None
    try:
        cl = int(first("class", "class_level", "primary", "grade", "year"))
    except (TypeError, ValueError):
        return None
    subject = str(first("subject", "topic_subject") or "").strip()[:80]
    question = str(first("question", "prompt", "question_text") or "").strip()
    options = first("options", "choices")
    if isinstance(options, str):
        try:
            options = json.loads(options)
        except json.JSONDecodeError:
            options = None
    if not isinstance(options, list):
        options = [first("option_a", "a", "option 1", "choice_a"),
                   first("option_b", "b", "option 2", "choice_b"),
                   first("option_c", "c", "option 3", "choice_c"),
                   first("option_d", "d", "option 4", "choice_d")]
    options = [str(x).strip() if x is not None else "" for x in options]
    raw_answer = first("answer", "correct_answer", "answer_key", "correct_option", "key")
    answer = None
    if type(raw_answer) is int:
        answer = raw_answer
    elif raw_answer is not None:
        val = str(raw_answer).strip()
        if val == "0": answer = 0
        elif re.fullmatch(r"[1-4]", val): answer = int(val) - 1
        elif val.upper() in ("A", "B", "C", "D"): answer = ord(val.upper()) - ord("A")
        else:
            matches = [i for i, opt in enumerate(options) if opt.casefold() == val.casefold()]
            if len(matches) == 1: answer = matches[0]
    explanation = str(first("explanation", "rationale", "solution") or "").strip()[:2000]
    category = str(first("category", "topic", "unit") or "").strip()[:80]
    if (cl not in range(1, 7) or not subject or not question or len(question) > 4000
            or len(options) != 4 or any(not x or len(x) > 1000 for x in options)
            or answer not in range(4)):
        return None
    return {"class": cl, "subject": subject, "question": question,
            "options": options, "answer": answer, "explanation": explanation, "category": category}


def question_fingerprint(q):
    # Duplicate detection is intentionally based on class, subject and normalized question text.
    parts = [str(q["class"]), q["subject"].casefold().strip(),
             " ".join(unicodedata.normalize("NFKC", q["question"]).casefold().split())]
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


def insert_question(conn, q, source_name):
    fp = question_fingerprint(q)
    cur = conn.execute("INSERT OR IGNORE INTO question_bank(class_level,subject,question,options_json,fingerprint,source_name,category) VALUES(?,?,?,?,?,?,?)",
        (q["class"], q["subject"], q["question"], json.dumps(q["options"], ensure_ascii=False), fp, source_name[:255], q.get("category", "")[:80]))
    if cur.rowcount:
        conn.execute("INSERT INTO question_answer_keys(question_id,answer_index,explanation) VALUES(?,?,?)",
                     (cur.lastrowid, q["answer"], q.get("explanation", "")))
        return True
    return False


def bank():
    """Read questions and answer keys from SQLite; answer keys remain server-side."""
    try:
        with db_connect() as conn:
            records = conn.execute("""SELECT q.id,q.class_level,q.subject,q.question,q.options_json,q.category,a.answer_index,a.explanation
                FROM question_bank q JOIN question_answer_keys a ON a.question_id=q.id ORDER BY q.id""").fetchall()
        return [{"id": r["id"], "class": r["class_level"], "subject": r["subject"], "question": r["question"],
                 "options": json.loads(r["options_json"]), "answer": r["answer_index"],
                 "explanation": r["explanation"], "category": r["category"]} for r in records]
    except (sqlite3.Error, ValueError, TypeError):
        app.logger.exception("Could not load question bank")
        return []


def parse_question_upload(file_storage):
    """Parse JSON, CSV or XLSX with row-level validation and a strict upload ceiling."""
    filename = Path(file_storage.filename or "upload").name
    suffix = Path(filename).suffix.lower()
    raw = file_storage.read()
    if not raw:
        raise ValueError("The uploaded file is empty.")
    if len(raw) > 20 * 1024 * 1024:
        raise ValueError("File is larger than the 20 MB upload limit.")
    rows_in = []
    if suffix == ".json":
        try: data = json.loads(raw.decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc: raise ValueError("JSON file could not be read: " + str(exc))
        if isinstance(data, dict): data = data.get("questions")
        if not isinstance(data, list): raise ValueError("JSON must contain a list of questions or an object with a 'questions' list.")
        rows_in = [(i + 1, row) for i, row in enumerate(data)]
    elif suffix == ".csv":
        try: text = raw.decode("utf-8-sig")
        except UnicodeDecodeError: raise ValueError("CSV must be saved as UTF-8.")
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames: raise ValueError("CSV needs a header row. Download the template from the teacher panel.")
        rows_in = [(i + 2, {str(k).strip().lower(): v for k, v in row.items() if k is not None}) for i, row in enumerate(reader)]
    elif suffix in (".xlsx", ".xlsm"):
        try:
            from openpyxl import load_workbook
            wb = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        except ImportError: raise ValueError("Excel import needs openpyxl. Run: python -m pip install -r requirements.txt")
        except Exception as exc: raise ValueError("Excel workbook could not be read: " + str(exc))
        ws = wb.active
        iterator = ws.iter_rows(values_only=True)
        headers = next(iterator, None)
        if not headers: raise ValueError("Excel sheet needs a header row.")
        keys = [str(h).strip().lower() if h is not None else "" for h in headers]
        rows_in = [(i + 2, {keys[j]: val for j, val in enumerate(row) if j < len(keys) and keys[j]}) for i, row in enumerate(iterator)]
        wb.close()
    else:
        raise ValueError("Unsupported file type. Upload .csv, .json, .xlsx or .xlsm.")
    if len(rows_in) > 100000: raise ValueError("A single import is limited to 100,000 rows.")
    parsed, errors = [], []
    for row_num, raw_row in rows_in:
        q = normalize_question(raw_row)
        if q is None:
            errors.append({"row": row_num, "message": "Missing/invalid class, subject, question, four options, or answer key."})
        else:
            parsed.append(q)
    return filename, parsed, errors, len(rows_in)


init_db()

def client_ip():
    # Never trust X-Forwarded-For on this local-only server; use the direct peer address.
    return request.remote_addr or "unknown"

def record_security_event(ip, event_type, details):
    clean_details = str(details)[:300]
    with security_lock:
        security_state["events"].insert(0, {"ip": ip, "type": event_type, "details": clean_details, "time": time.strftime("%Y-%m-%d %H:%M:%S")})
        del security_state["events"][50:]
    try:
        with db_connect() as conn:
            conn.execute("INSERT INTO security_events(ip_address,event_type,details) VALUES(?,?,?)", (ip, event_type, clean_details))
            conn.execute("DELETE FROM security_events WHERE id NOT IN (SELECT id FROM security_events ORDER BY id DESC LIMIT 200)")
    except sqlite3.Error:
        app.logger.exception("Could not persist security event")

def quarantine_ip(ip, reason, seconds=900):
    if ip in ("127.0.0.1", "::1", "unknown"):
        # Localhost can still trigger global lockdown, but never auto-quarantine the host itself.
        return
    with security_lock:
        security_state["blocked_ips"][ip] = {"until": time.time() + seconds, "reason": str(reason)[:200]}
    record_security_event(ip, "ip_quarantined", reason)

def ip_is_quarantined(ip):
    with security_lock:
        entry = security_state["blocked_ips"].get(ip)
        if not entry:
            return False
        if entry["until"] <= time.time():
            security_state["blocked_ips"].pop(ip, None)
            return False
        return True

def persist_lockdown():
    try:
        value = json.dumps({"enabled": security_state["lockdown"], "reason": security_state["reason"], "since": security_state["since"]})
        with db_connect() as conn:
            conn.execute("INSERT INTO security_control(control_key,control_value) VALUES('lockdown',?) ON CONFLICT(control_key) DO UPDATE SET control_value=excluded.control_value", (value,))
    except sqlite3.Error:
        app.logger.exception("Could not persist emergency lockdown state")

@app.before_request
def security_gate():
    ip = client_ip()
    path = request.path.lower()
    if ip_is_quarantined(ip):
        return jsonify(ok=False, locked=True, message="This device has been temporarily isolated by the quiz server's security protection. Ask the teacher to review it."), 403
    if any(path.startswith(p) for p in SUSPICIOUS_PATHS):
        quarantine_ip(ip, "Request for a common sensitive/probe path: " + request.path)
        return jsonify(ok=False, locked=True, message="Request blocked by server security."), 403
    # Socket.IO polling/websocket heartbeats generate frequent transport requests
    # during normal classroom use. Do not count those as application/API traffic.
    # The old 180/30s limit could quarantine a legitimate pupil/display device,
    # especially when several tabs shared one school-NAT/Wi-Fi address.
    if not path.startswith("/socket.io/"):
        now = time.time()
        with security_lock:
            window = security_state["request_windows"].setdefault(ip, [])
            window[:] = [t for t in window if now - t < 30]
            window.append(now)
            if len(window) > 600:
                quarantine_ip(ip, "Sustained excessive application request rate (>600 requests in 30 seconds)", 300)
                return jsonify(ok=False, locked=True, message="Request rate exceeded; this device is temporarily isolated."), 429
    if security_state["lockdown"] and request.path in LOCKDOWN_STUDENT_PATHS:
        if request.path == "/":
            return render_template("student.html", emergency_lockdown=True), 200
        return jsonify(ok=False, locked=True, message="EMERGENCY LOCKDOWN is active. Student access is temporarily paused. Please contact the teacher."), 423

@app.after_request
def detect_unauthorized_teacher_api(response):
    path = request.path
    ip = client_ip()
    if path.startswith("/api/teacher/") and path != "/api/teacher/login" and response.status_code in (401, 403):
        now = time.time()
        with security_lock:
            window = security_state["unauthorized_windows"].setdefault(ip, [])
            window[:] = [t for t in window if now - t < 120]
            window.append(now)
            count = len(window)
        record_security_event(ip, "unauthorized_teacher_api", path)
        if count >= 5:
            quarantine_ip(ip, "Repeated unauthorized attempts against teacher-only endpoints", 900)
    # Notify connected classroom screens after a successful state-changing API call.
    # The event carries no quiz data; clients fetch fresh data through existing APIs.
    if request.path.startswith("/api/") and request.method in {"POST", "PUT", "PATCH", "DELETE"} and response.status_code < 400:
        try:
            socketio.emit("quiz_state_changed", {"source": request.path})
        except Exception:
            app.logger.exception("Could not publish quiz state change")
    return response

def teacher_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("teacher_authenticated"):
            return jsonify(ok=False, message="Teacher login required."), 401
        return fn(*args, **kwargs)
    return wrapped

def remaining():
    if state["start"] is None: return state["duration"]
    return max(0, state["duration"] - int(time.time() - state["start"]))

def assigned_questions(p):
    if state["mode"] == "different": return p.get("questions", [])
    return state["questions"]

def score_player(p):
    if p.get("eliminated"): return 0
    qs=assigned_questions(p)
    answers=p.get("answers",{})
    score=0; streak=0
    for i,q in enumerate(qs):
        if str(i) not in answers: continue
        correct=answers[str(i)] == q.get("answer")
        if correct:
            streak += 1
            base = int(q.get("points", 10) or 10)
            score += base * (2 if i in p.get("double_points",[]) else 1)
            if streak >= 3: score += 5
        else:
            streak=0
    return score

def rows():
    out=[]
    for code,p in state["players"].items():
        qs=assigned_questions(p)
        out.append({"name":p["name"],"code":code,"score":score_player(p),"total":len(qs)*15+10,
                    "submitted":p["submitted"],"team":p.get("team",""),"answered":len(p.get("answers",{})),"eliminated":bool(p.get("eliminated",False)),"online":(time.time()-float(p.get("last_seen",0) or 0))<=35,"last_seen":p.get("last_seen")})
    out.sort(key=lambda r:(-r["score"],r["name"].lower()))
    return out

def leaderboard():
    people=rows()
    if state["competition"] == "team":
        teams={}
        for r in people:
            name=r["team"] or "Unassigned"
            t=teams.setdefault(name,{"name":name,"score":0,"total":0,"members":0,"submitted":True})
            t["score"]+=r["score"]; t["total"]+=r["total"]; t["members"]+=1; t["submitted"]=t["submitted"] and r["submitted"]
        return sorted(teams.values(),key=lambda t:(-t["score"],t["name"].lower()))
    return people

def safe_question(q):
    return {"question":q["question"],"options":q["options"],"subject":q.get("subject",""),"points":int(q.get("points",10) or 10)}

def maybe_finish():
    if state["start"] is not None and remaining() <= 0 and not state["finished"]:
        state["finished"] = True
        save_final_results()
        persist_runtime_state()


@app.errorhandler(413)
def upload_too_large(_error):
    return jsonify(ok=False, message="Upload exceeds the 20 MB file limit."), 413

@app.get("/")
def student(): return render_template("student.html")
@app.get("/teacher")
def teacher(): return render_template("teacher.html")
@app.get("/display")
def display(): return render_template("display.html")

@app.get("/api/teacher/question-bank")
@teacher_required
def question_bank_summary():
    with db_connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM question_bank").fetchone()[0]
        grouped = conn.execute("SELECT class_level,subject,COUNT(*) AS n FROM question_bank GROUP BY class_level,subject ORDER BY class_level,subject").fetchall()
    return jsonify(ok=True,total=total,by_class_subject=[dict(r) for r in grouped],max_import_rows=100000,max_file_mb=20)


@app.get("/api/teacher/question-template.csv")
@teacher_required
def question_template():
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["class", "subject", "category", "question", "option_a", "option_b", "option_c", "option_d", "answer", "explanation"])
    writer.writerow(["4", "Mathematics", "Arithmetic", "What is 7 + 5?", "10", "11", "12", "13", "C", "7 + 5 = 12."])
    from flask import Response
    return Response(output.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=question_bank_template.csv"})


@app.get("/api/teacher/question-bank/export.csv")
@teacher_required
def export_question_bank():
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["class", "subject", "category", "question", "option_a", "option_b", "option_c", "option_d", "answer", "explanation"])
    for q in bank():
        writer.writerow([q["class"],q["subject"],q.get("category", ""),q["question"],*q["options"],chr(65+q["answer"]),q.get("explanation","")])
    from flask import Response
    return Response(output.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=question_bank_export.csv"})


@app.post("/api/teacher/question-bank/preview")
@teacher_required
def preview_question_import():
    if "file" not in request.files: return jsonify(ok=False,message="Choose a question file first."),400
    try:
        filename, parsed, errors, total_rows = parse_question_upload(request.files["file"])
        with db_connect() as conn:
            existing = {r[0] for r in conn.execute("SELECT fingerprint FROM question_bank")}
        seen, duplicates = set(), 0
        for q in parsed:
            fp=question_fingerprint(q)
            if fp in existing or fp in seen: duplicates += 1
            seen.add(fp)
        return jsonify(ok=True,filename=filename,rows_read=total_rows,valid=len(parsed),invalid=len(errors),
            duplicates=duplicates,new_questions=max(0,len(parsed)-duplicates),errors=errors[:100],
            sample=[{"class":q["class"],"subject":q["subject"],"question":q["question"],"answer":chr(65+q["answer"])} for q in parsed[:10]],
            message=f"Preview: {len(parsed)} valid rows, {len(errors)} invalid rows, {duplicates} duplicates, approximately {max(0,len(parsed)-duplicates)} new questions.")
    except ValueError as exc: return jsonify(ok=False,message=str(exc)),400


@app.post("/api/teacher/question-bank/import")
@teacher_required
def import_question_bank():
    if "file" not in request.files: return jsonify(ok=False,message="Choose a question file first."),400
    try:
        filename, parsed, errors, total_rows = parse_question_upload(request.files["file"])
        if not parsed: return jsonify(ok=False,message="No valid questions found; nothing was imported.",errors=errors[:100]),400
        added=0; duplicates=0
        # One transaction ensures the import is all-or-nothing on database errors.
        with db_connect() as conn:
            try:
                conn.execute("BEGIN IMMEDIATE")
                cur = conn.execute("INSERT INTO question_import_batches(filename,imported_count,skipped_count,invalid_count) VALUES(?,?,?,?)",
                                   (filename[:255], 0, 0, len(errors)))
                batch_id = cur.lastrowid
                for q in parsed:
                    if insert_question(conn,q,filename):
                        added += 1
                        fp = question_fingerprint(q)
                        row = conn.execute("SELECT id FROM question_bank WHERE fingerprint=?", (fp,)).fetchone()
                        if row:
                            conn.execute("INSERT OR IGNORE INTO question_import_batch_items(batch_id,question_id) VALUES(?,?)", (batch_id,row[0]))
                    else: duplicates += 1
                conn.execute("UPDATE question_import_batches SET imported_count=?,skipped_count=? WHERE id=?", (added,duplicates,batch_id))
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        with lock:
            persist_runtime_state()
        return jsonify(ok=True,filename=filename,rows_read=total_rows,valid=len(parsed),invalid=len(errors),
            imported=added,duplicates=duplicates,batch_id=batch_id,errors=errors[:100],
            message=f"Import complete: added {added} questions; skipped {duplicates} duplicates; {len(errors)} invalid rows were skipped.")
    except ValueError as exc: return jsonify(ok=False,message=str(exc)),400
    except sqlite3.Error:
        app.logger.exception("Question bank import failed")
        return jsonify(ok=False,message="Database import failed; no partial import was committed."),500


@app.get("/api/teacher/question-bank/manage")
@teacher_required
def manage_question_bank():
    query = request.args.get("q", "").strip()[:200]
    cl = request.args.get("class", "").strip()
    subject = request.args.get("subject", "").strip()[:80]
    category = request.args.get("category", "").strip()[:80]
    page = max(1, min(100000, int(request.args.get("page", "1") or 1)))
    limit = max(10, min(100, int(request.args.get("limit", "25") or 25)))
    where, args = [], []
    if query:
        where.append("(q.question LIKE ? OR q.subject LIKE ? OR q.category LIKE ? OR q.source_name LIKE ?)")
        args.extend([f"%{query}%"]*4)
    if cl in {str(i) for i in range(1,7)}: where.append("q.class_level=?"); args.append(int(cl))
    if subject: where.append("q.subject=?"); args.append(subject)
    if category: where.append("q.category=?"); args.append(category)
    clause = " WHERE " + " AND ".join(where) if where else ""
    with db_connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM question_bank q"+clause, args).fetchone()[0]
        rows = conn.execute("SELECT q.id,q.class_level,q.subject,q.category,q.question,q.options_json,q.source_name,q.created_at,a.answer_index,a.explanation FROM question_bank q JOIN question_answer_keys a ON a.question_id=q.id"+clause+" ORDER BY q.id DESC LIMIT ? OFFSET ?", args+[limit,(page-1)*limit]).fetchall()
        subjects = [r[0] for r in conn.execute("SELECT DISTINCT subject FROM question_bank ORDER BY subject")]
        categories = [r[0] for r in conn.execute("SELECT DISTINCT category FROM question_bank WHERE category<>'' ORDER BY category")]
    return jsonify(ok=True,total=total,page=page,limit=limit,pages=max(1,(total+limit-1)//limit),subjects=subjects,categories=categories,
        questions=[{"id":r["id"],"class":r["class_level"],"subject":r["subject"],"category":r["category"],"question":r["question"],"options":json.loads(r["options_json"]),"answer":r["answer_index"],"explanation":r["explanation"],"source":r["source_name"],"created_at":r["created_at"]} for r in rows])

@app.put("/api/teacher/question-bank/<int:question_id>")
@teacher_required
def edit_bank_question(question_id):
    data=request.get_json(silent=True) or {}
    q=normalize_question(data)
    if not q: return jsonify(ok=False,message="Invalid question. Provide class 1–6, subject, question, four options and answer key A–D."),400
    with db_connect() as conn:
        existing=conn.execute("SELECT id FROM question_bank WHERE id=?",(question_id,)).fetchone()
        if not existing: return jsonify(ok=False,message="Question not found."),404
        fp=question_fingerprint(q)
        duplicate=conn.execute("SELECT id FROM question_bank WHERE fingerprint=? AND id<>?",(fp,question_id)).fetchone()
        if duplicate: return jsonify(ok=False,message=f"This question duplicates question #{duplicate['id']}; edit cancelled."),409
        conn.execute("UPDATE question_bank SET class_level=?,subject=?,question=?,options_json=?,fingerprint=?,category=? WHERE id=?",
            (q["class"],q["subject"],q["question"],json.dumps(q["options"],ensure_ascii=False),fp,q.get("category",""),question_id))
        conn.execute("UPDATE question_answer_keys SET answer_index=?,explanation=? WHERE question_id=?",(q["answer"],q.get("explanation",""),question_id))
    return jsonify(ok=True,message="Question updated.")

@app.delete("/api/teacher/question-bank/<int:question_id>")
@teacher_required
def delete_bank_question(question_id):
    with db_connect() as conn:
        cur=conn.execute("DELETE FROM question_bank WHERE id=?",(question_id,))
    if not cur.rowcount: return jsonify(ok=False,message="Question not found."),404
    return jsonify(ok=True,message="Question deleted.")

@app.post("/api/teacher/question-bank/bulk-delete")
@teacher_required
def bulk_delete_bank_questions():
    data=request.get_json(silent=True) or {}; ids=data.get("ids")
    if not isinstance(ids,list) or not ids or len(ids)>500 or any(type(x) is not int or x<1 for x in ids):
        return jsonify(ok=False,message="Select between 1 and 500 valid question IDs."),400
    with db_connect() as conn:
        marks=','.join('?' for _ in set(ids)); cur=conn.execute(f"DELETE FROM question_bank WHERE id IN ({marks})",list(set(ids)))
    return jsonify(ok=True,deleted=cur.rowcount,message=f"Deleted {cur.rowcount} questions.")

@app.get("/api/teacher/question-bank/import-history")
@teacher_required
def question_import_history():
    with db_connect() as conn:
        rows=conn.execute("SELECT id,filename,imported_count,skipped_count,invalid_count,created_at,rolled_back FROM question_import_batches ORDER BY id DESC LIMIT 50").fetchall()
    return jsonify(ok=True,batches=[dict(r) for r in rows])

@app.post("/api/teacher/question-bank/import-history/<int:batch_id>/rollback")
@teacher_required
def rollback_question_import(batch_id):
    with db_connect() as conn:
        batch=conn.execute("SELECT * FROM question_import_batches WHERE id=?",(batch_id,)).fetchone()
        if not batch: return jsonify(ok=False,message="Import batch not found."),404
        if batch["rolled_back"]: return jsonify(ok=False,message="This import batch was already rolled back."),409
        ids=[r[0] for r in conn.execute("SELECT question_id FROM question_import_batch_items WHERE batch_id=?",(batch_id,))]
        if ids:
            marks=','.join('?' for _ in ids); conn.execute(f"DELETE FROM question_bank WHERE id IN ({marks})",ids)
        conn.execute("UPDATE question_import_batches SET rolled_back=1 WHERE id=?",(batch_id,))
    return jsonify(ok=True,deleted=len(ids),message=f"Rolled back import batch {batch_id}; removed {len(ids)} questions added by that import.")

@app.get("/api/teacher/question-bank/backup.sqlite3")
@teacher_required
def download_question_bank_backup():
    import tempfile
    from flask import send_file
    with tempfile.NamedTemporaryFile(prefix="quiz_question_bank_",suffix=".sqlite3",delete=False) as tmp: path=tmp.name
    try:
        with sqlite3.connect(path) as target, db_connect() as source: source.backup(target)
        return send_file(path,as_attachment=True,download_name="primary_quiz_question_bank_backup.sqlite3",mimetype="application/vnd.sqlite3")
    finally:
        # The file is intentionally left for send_file to stream; it is small/local and OS temp cleanup handles it.
        pass

@app.post("/api/teacher/create")
@teacher_required
def create():
    d=request.get_json(silent=True) or {}
    try:
        cl=max(1,min(6,int(d.get("class_level",4))))
        rapid_fire = bool(d.get("rapid_fire", False))
        tournament_enabled = bool(d.get("tournament_enabled", True))
        mins=1 if rapid_fire else max(1,min(180,int(d.get("duration",10))))
        count=max(1,min(100,int(d.get("count",10))))
        subject=str(d.get("subject","Mathematics"))
        mode=str(d.get("mode","same")); comp=str(d.get("competition","individual"))
        if mode not in ("same","different"): mode="same"
        if comp not in ("individual","team"): comp="individual"
        title=str(d.get("title","Primary School Quiz Challenge")).strip()[:80] or "Primary School Quiz Challenge"
        pin=str(d.get("pin","2468")).strip()
        if not re.fullmatch(r"[A-Za-z0-9]{4,12}", pin):
            return jsonify(ok=False,message="Competition PIN must be 4–12 letters or numbers.")
        team_names=[str(d.get("team_a","Team A")).strip()[:30] or "Team A",str(d.get("team_b","Team B")).strip()[:30] or "Team B"]
        if comp == "team" and team_names[0].casefold() == team_names[1].casefold():
            return jsonify(ok=False,message="Team A and Team B must have different names.")
        pool=[q for q in bank() if q["class"] == cl and (subject=="All subjects" or q["subject"]==subject)]
        if not pool: return jsonify(ok=False,message="No matching questions found in the question database. Import more questions or choose another class/subject.")
        if rapid_fire:
            count=min(100,len(pool))
        with lock:
            random.shuffle(pool)
            if mode=="same":
                questions=pool[:min(count,len(pool))]
                if len(questions)<count: pass
            else:
                need=min(count,len(pool))
                if len(pool)<4:
                    return jsonify(ok=False,message="Different-question mode needs at least four questions in the selected class/subject. Add more questions or choose All subjects.")
                questions=[]
            stages = ([
            {"name":"Qualifying Round","type":"standard","duration":mins*60,"count":min(count,len(pool)),"advance":"all"},
            {"name":"Elimination Round","type":"standard","duration":mins*60,"count":min(count,len(pool)),"advance":"top75"},
            {"name":"Quarter-Final","type":"category_bank","duration":mins*60,"count":min(count,len(pool)),"advance":"top50"},
            {"name":"Semi-Final","type":"rapid_fire","duration":60,"count":min(100,len(pool)),"advance":"top50"},
            {"name":"Grand Finale","type":"final_mix","duration":mins*60,"count":min(count,len(pool)),"advance":"all"}
        ] if tournament_enabled else [{"name":"Practice Round","type":"rapid_fire" if rapid_fire else "standard","duration":mins*60,"count":min(count,len(pool)),"advance":"all"}])
            state.update(active=True,pin=pin,class_level=cl,subject=subject,duration=stages[0]["duration"],start=None,
                         questions=questions,players={},finished=False,rapid_fire=rapid_fire,show_mode=bool(d.get("show_mode",True)),mode=mode,competition=comp,title=title,
                         team_names=team_names,created=time.time(),question_count=min(count,len(pool)),history_saved=False,history_id=None,
                         tournament_enabled=tournament_enabled,stages=stages,stage_index=0,round_type=stages[0]["type"],eliminated_players=[],stage_history=[],selected_category="")
            persist_runtime_state()
        actual=min(count,len(pool))
        msg=(f"Tournament ready: {len(stages)} stages, beginning with {stages[0]['name']}. Up to four pupils can join." if tournament_enabled else (f"60 Seconds of Fame practice round ready. {actual} rapid-fire questions per pupil; the clock is fixed at 60 seconds." if rapid_fire else f"Session ready for up to four pupils. {actual} questions per pupil."))
        if mode=="same" and actual<count: msg+=f" The question bank has only {actual} matching questions; add more for the requested {count}."
        return jsonify(ok=True,message=msg,question_count=actual)
    except Exception as e: return jsonify(ok=False,message="Could not create session: "+str(e))

@app.post("/api/teacher/start")
@teacher_required
def start():
    with lock:
        if not state["active"]: return jsonify(ok=False,message="Create a session first.")
        if not state["players"]: return jsonify(ok=False,message="No pupils have joined yet.")
        if state["start"] is not None:
            return jsonify(ok=False,message="This competition has already started or ended. Create a new session to restart.")
        state["start"]=time.time(); state["finished"]=False
        state["duration"] = int(state.get("stages", [{}])[state.get("stage_index",0)].get("duration", state["duration"]))
        state["round_type"] = state.get("stages", [{}])[state.get("stage_index",0)].get("type", "standard")
        state["rapid_fire"] = state["round_type"] == "rapid_fire"
        persist_runtime_state()
    return jsonify(ok=True,message="Competition started.")

@app.post("/api/teacher/end")
@teacher_required
def end():
    with lock:
        if not state["active"]: return jsonify(ok=False,message="There is no active competition.")
        if state["start"] is None:
            state["active"] = False
            state["finished"] = True
            persist_runtime_state()
            return jsonify(ok=True,message="Waiting session cancelled. No results were recorded.")
        state["finished"]=True
        save_final_results()
        persist_runtime_state()
    return jsonify(ok=True,message="Competition ended. Final results are displayed and saved to local history.")

@app.post("/api/teacher/advance-stage")
@teacher_required
def advance_stage():
    """Advance the primary-school tournament to its next configured stage."""
    with lock:
        stages = state.get("stages", [])
        idx = int(state.get("stage_index", 0))
        if not state.get("active") or not state.get("finished"):
            return jsonify(ok=False, message="Finish the current stage before advancing."), 409
        if idx + 1 >= len(stages):
            return jsonify(ok=False, message="The Grand Finale is complete. Start a new tournament for another competition."), 409
        current_rows = rows()
        current = stages[idx]
        state.setdefault("stage_history", []).append({"stage": current.get("name"), "results": current_rows})
        rule = current.get("advance", "all")
        eligible = [code for code, player in state["players"].items() if not player.get("eliminated")]
        ranked = sorted(eligible, key=lambda code: (-score_player(state["players"][code]), state["players"][code]["name"].lower()))
        if rule == "top75": keep = max(1, (len(ranked) * 3 + 3) // 4)
        elif rule == "top50": keep = max(1, (len(ranked) + 1) // 2)
        else: keep = len(ranked)
        advancing = set(ranked[:keep])
        for code, player in state["players"].items():
            if code not in advancing:
                player["eliminated"] = True
                if code not in state.setdefault("eliminated_players", []): state["eliminated_players"].append(code)
        state["stage_index"] = idx + 1
        stage = stages[idx + 1]
        pool = [q for q in bank() if q["class"] == state["class_level"] and (state["subject"] == "All subjects" or q["subject"] == state["subject"])]
        selected_category = ""
        if stage.get("type") == "category_bank":
            category_groups = {}
            for item in pool:
                category = str(item.get("category", "")).strip()
                if category: category_groups.setdefault(category, []).append(item)
            if not category_groups and state["subject"] == "All subjects":
                for item in pool:
                    category_groups.setdefault(str(item.get("subject", "General")), []).append(item)
            if category_groups:
                # A randomly drawn topic/subject becomes the category challenge.
                selected_category = random.choice(sorted(category_groups))
                pool = category_groups[selected_category]
        random.shuffle(pool)
        count = min(int(stage.get("count", state.get("question_count", 10))), len(pool))
        if count < 1:
            return jsonify(ok=False, message="No questions are available for the next stage."), 409
        questions = pool[:count]
        state["questions"] = questions if state["mode"] == "same" else []
        for code, player in state["players"].items():
            if player.get("eliminated"): continue
            player["questions"] = random.sample(pool, count) if state["mode"] == "different" else []
            player["answers"] = {}; player["submitted"] = False; player["current_index"] = 0
            player["lifelines"] = {"fifty_fifty": 1, "double_points": 1}
            player["eliminated_options"] = {}; player["double_points"] = []
        state["duration"] = int(stage.get("duration", 600))
        state["round_type"] = stage.get("type", "standard")
        state["rapid_fire"] = state["round_type"] == "rapid_fire"
        state["question_count"] = count
        state["selected_category"] = selected_category
        state["start"] = None; state["finished"] = False; state["history_saved"] = False; state["history_id"] = None
        persist_runtime_state()
    socketio.emit("quiz_state_changed", {"event":"stage_advanced"})
    return jsonify(ok=True, message=f"Advanced to {stage['name']}. Eligible pupils can begin the next stage.", stage=stage, advancing=len(advancing), eliminated=len(state.get("eliminated_players", [])))


@app.post("/api/teacher/login")
def teacher_login():
    d = request.get_json(silent=True) or {}
    supplied = str(d.get("pin", ""))[:32]
    ip = client_ip()
    if not hmac.compare_digest(supplied, TEACHER_PIN):
        # Count failed PIN attempts independently of other teacher API calls.
        now = time.time()
        with security_lock:
            window = security_state["unauthorized_windows"].setdefault(ip, [])
            window[:] = [stamp for stamp in window if now - stamp < 120]
            window.append(now)
            failures = len(window)
        record_security_event(ip, "failed_teacher_login", f"Failed teacher PIN attempt ({failures} in 120 seconds)")
        if failures >= 5:
            quarantine_ip(ip, "Five or more failed teacher PIN attempts in 120 seconds", 900)
        return jsonify(ok=False, message="Incorrect teacher access PIN."), 403
    with security_lock:
        security_state["unauthorized_windows"].pop(ip, None)
    session["teacher_authenticated"] = True
    record_security_event(ip, "teacher_login_success", "Teacher authenticated successfully")
    return jsonify(ok=True, message="Teacher access granted.")


@app.post("/api/teacher/logout")
@teacher_required
def teacher_logout():
    session.clear()
    return jsonify(ok=True, message="Teacher logged out.")


@app.get("/api/teacher/status")
@teacher_required
def teacher_status():
    with lock:
        maybe_finish()
        return jsonify(active=state["active"],started=state["start"] is not None,finished=state["finished"],
          rows=rows(),leaderboard=leaderboard(),mode=state["mode"],competition=state["competition"],
          title=state["title"],remaining=remaining(),class_level=state["class_level"],subject=state["subject"],
          question_count=state.get("question_count",len(state["questions"])),players_count=len(state["players"]),team_names=state["team_names"],rapid_fire=state.get("rapid_fire",False),
          stage=(state.get("stages") or [{"name":"Practice Round"}])[state.get("stage_index",0)],stage_index=state.get("stage_index",0),stage_count=len(state.get("stages",[])),round_type=state.get("round_type","standard"),eliminated_count=len(state.get("eliminated_players",[])),selected_category=state.get("selected_category",""))

@app.post("/api/teacher/assign-team")
@teacher_required
def assign_team():
    d = request.get_json(silent=True) or {}
    code = str(d.get("code", ""))
    team = str(d.get("team", ""))
    with lock:
        if state["competition"] != "team":
            return jsonify(ok=False, message="Manual team assignment is available only in team mode."), 400
        if state["start"] is not None:
            return jsonify(ok=False, message="Teams cannot be changed after the competition starts."), 409
        if code not in state["players"]:
            return jsonify(ok=False, message="Pupil session not found."), 404
        if team not in state["team_names"]:
            return jsonify(ok=False, message="Choose one of the configured teams."), 400
        state["players"][code]["team"] = team
    return jsonify(ok=True, message="Team assignment updated.")


@app.get("/api/teacher/history")
@teacher_required
def teacher_history():
    try:
        with db_connect() as conn:
            records = conn.execute("SELECT id,finished_at,title,class_level,subject,competition_mode,question_mode,question_count,results_json FROM competition_history ORDER BY id DESC LIMIT 25").fetchall()
        out=[]
        for r in records:
            try: result=json.loads(r["results_json"])
            except json.JSONDecodeError: result={}
            out.append({"id":r["id"],"finished_at":r["finished_at"],"title":r["title"],
                "class_level":r["class_level"],"subject":r["subject"],"competition":r["competition_mode"],
                "mode":r["question_mode"],"question_count":r["question_count"],"results":result})
        return jsonify(ok=True,history=out)
    except sqlite3.Error:
        app.logger.exception("Could not read competition history")
        return jsonify(ok=False,message="Competition history is temporarily unavailable."), 500


@app.get("/api/teacher/security")
@teacher_required
def security_status():
    with security_lock:
        now = time.time()
        blocked = [{"ip": ip, "reason": entry["reason"], "seconds_remaining": max(0, int(entry["until"] - now))}
                   for ip, entry in security_state["blocked_ips"].items() if entry["until"] > now]
        events = list(security_state["events"][:20])
        result = {"lockdown": security_state["lockdown"], "reason": security_state["reason"],
                  "since": security_state["since"], "blocked_ips": blocked, "events": events}
    try:
        with db_connect() as conn:
            rows = conn.execute("SELECT created_at,ip_address,event_type,details FROM security_events ORDER BY id DESC LIMIT 20").fetchall()
        result["events"] = [{"time": r["created_at"], "ip": r["ip_address"], "type": r["event_type"], "details": r["details"]} for r in rows]
    except sqlite3.Error:
        pass
    return jsonify(ok=True, **result)

@app.post("/api/teacher/security/lockdown")
@teacher_required
def set_emergency_lockdown():
    d = request.get_json(silent=True) or {}
    enabled = bool(d.get("enabled"))
    reason = str(d.get("reason", "Teacher activated emergency lockdown" if enabled else "Teacher cleared emergency lockdown")).strip()[:200]
    with security_lock:
        security_state["lockdown"] = enabled
        security_state["reason"] = reason if enabled else ""
        security_state["since"] = time.strftime("%Y-%m-%d %H:%M:%S") if enabled else None
    persist_lockdown()
    record_security_event(client_ip(), "manual_lockdown_on" if enabled else "manual_lockdown_off", reason or "No reason supplied")
    return jsonify(ok=True, lockdown=enabled, message="Emergency lockdown activated. Student joining and answer APIs are paused." if enabled else "Emergency lockdown cleared. Student access is restored.")

@app.post("/api/teacher/security/unblock")
@teacher_required
def unblock_quarantined_ip():
    d = request.get_json(silent=True) or {}
    ip = str(d.get("ip", "")).strip()
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        return jsonify(ok=False, message="Enter a valid IP address."), 400
    with security_lock:
        existed = security_state["blocked_ips"].pop(ip, None) is not None
        security_state["unauthorized_windows"].pop(ip, None)
        security_state["request_windows"].pop(ip, None)
    record_security_event(client_ip(), "teacher_unblocked_ip", ip)
    return jsonify(ok=True, message=("Device quarantine cleared for " if existed else "No active quarantine for ") + ip + ".")

@app.post("/api/join")
def join():
    d=request.get_json(silent=True) or {}; name=str(d.get("name"," ")).strip()[:40]; pin=str(d.get("pin","")).strip()
    if not name: return jsonify(ok=False,message="Enter a pupil name.")
    with lock:
        if not state["active"]: return jsonify(ok=False,message="Teacher has not created a session.")
        if pin!=state["pin"]: return jsonify(ok=False,message="Incorrect PIN.")
        if state["start"] is not None: return jsonify(ok=False,message="Competition already started.")
        if len(state["players"])>=MAX_PLAYERS: return jsonify(ok=False,message="This session is limited to four pupils.")
        if any(p["name"].casefold() == name.casefold() for p in state["players"].values()):
            return jsonify(ok=False,message="That pupil name is already in use.")
        code="P"+secrets.token_urlsafe(18).replace("-", "").replace("_", "").upper()
        while code in state["players"]: code="P"+secrets.token_hex(2).upper()
        team=state["team_names"][len(state["players"])%2] if state["competition"]=="team" else ""
        qs=[]
        if state["mode"]=="different":
            pool=[q for q in bank() if q["class"]==state["class_level"] and (state["subject"]=="All subjects" or q["subject"]==state["subject"])]
            random.shuffle(pool); qs=pool[:state.get("question_count",10)]
        state["players"][code]={"name":name,"answers":{},"submitted":False,"team":team,"questions":qs,"current_index":0,"lifelines":{"fifty_fifty":1,"double_points":1},"eliminated_options":{},"double_points":[],"last_seen":time.time()}
        persist_runtime_state()
    return jsonify(ok=True,message="Joined successfully.",code=code,team=team)


# --- Controlled local server firmware/application updates ---
UPDATE_DIR = ROOT / "updates"
STAGED_DIR = UPDATE_DIR / "staged"
UPDATE_MAX_BYTES = 25 * 1024 * 1024
UPDATE_ALLOWED = re.compile(r"^(server\.py|apply_update\.py|updater_worker\.py|requirements\.txt|templates/[A-Za-z0-9_.-]+\.html)$")

def _update_manifest_and_files(zf):
    names = zf.namelist()
    if len(names) != len(set(names)):
        raise ValueError("Package contains duplicate ZIP entries.")
    if len(names) > 250:
        raise ValueError("Update package contains too many files.")
    if "manifest.json" not in names:
        raise ValueError("Package is missing manifest.json.")
    if zf.getinfo("manifest.json").file_size > 256 * 1024:
        raise ValueError("Package manifest is too large.")
    manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
    version = str(manifest.get("version", "")).strip()
    if not re.fullmatch(r"\d+(?:\.\d+){1,3}", version):
        raise ValueError("Manifest version must be numeric, for example 1.2.3.")
    minimum = manifest.get("min_app_version")
    if minimum and _version_tuple(_current_app_version()) < _version_tuple(str(minimum)):
        raise ValueError("This update requires application version " + str(minimum) + " or newer.")
    declared = manifest.get("files")
    if not isinstance(declared, dict) or not declared:
        raise ValueError("Manifest must contain a non-empty files map.")
    verified = {}
    for name, expected in declared.items():
        name = str(name)
        if "\\" in name or not UPDATE_ALLOWED.fullmatch(name) or name.startswith("/") or ".." in Path(name).parts:
            raise ValueError("Update contains a file outside the permitted application paths: " + name)
        if name not in names:
            raise ValueError("Package is missing declared file: " + name)
        info = zf.getinfo(name)
        if info.file_size > 12 * 1024 * 1024 or (info.external_attr >> 16) & 0o170000 == 0o120000:
            raise ValueError("Unsafe or oversized update file: " + name)
        payload = zf.read(name)
        digest = hashlib.sha256(payload).hexdigest()
        if not hmac.compare_digest(digest, str(expected).lower()):
            raise ValueError("SHA-256 verification failed for " + name)
        verified[name] = payload
    unexpected = set(names) - set(declared) - {"manifest.json"}
    if unexpected:
        raise ValueError("Package contains undeclared files: " + ", ".join(sorted(unexpected)[:5]))
    return manifest, verified

def _current_app_version():
    try: return (ROOT / "APP_VERSION").read_text(encoding="utf-8").strip() or "1.0.0"
    except OSError: return "1.0.0"

def _version_tuple(value):
    # Compare the numeric release components; reject ambiguous labels for automatic checks.
    match = re.fullmatch(r"v?(\d+(?:\.\d+){0,3})(?:[-+][0-9A-Za-z.-]+)?", str(value).strip())
    if not match: raise ValueError("Automatic update versions must use numeric versions such as 1.2.3.")
    return tuple(int(part) for part in match.group(1).split("."))

def _load_update_feed():
    path = UPDATE_DIR / "update_feed.json"
    if not path.exists(): return ""
    try: return str(json.loads(path.read_text(encoding="utf-8")).get("url", ""))
    except (OSError, ValueError, TypeError): return ""

def _fetch_https_json(url, limit=256 * 1024):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("The update feed and package URLs must use HTTPS.")
    req = urllib.request.Request(url, headers={"User-Agent": "WOWBII-Updater/1.1", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=12) as response:
        if urllib.parse.urlparse(response.geturl()).scheme != "https": raise ValueError("Update feed redirected away from HTTPS.")
        if response.status != 200: raise ValueError("Update server returned HTTP " + str(response.status))
        data = response.read(limit + 1)
    if len(data) > limit: raise ValueError("Update feed is too large.")
    result = json.loads(data.decode("utf-8"))
    if not isinstance(result, dict): raise ValueError("Update feed must be a JSON object.")
    return result

def _stage_verified_update(raw, expected_version=None):
    if len(raw) > UPDATE_MAX_BYTES: raise ValueError("Update package exceeds the 25 MB limit.")
    with zipfile.ZipFile(io.BytesIO(raw), "r") as zf:
        infos = zf.infolist()
        if len(infos) > 250: raise ValueError("Update package contains too many files.")
        if sum(info.file_size for info in infos) > UPDATE_MAX_BYTES:
            raise ValueError("Update package expands beyond the 25 MB safety limit.")
        for info in infos:
            if info.file_size > 12 * 1024 * 1024 or info.flag_bits & 0x1 or ((info.external_attr >> 16) & 0o170000 == 0o120000):
                raise ValueError("Update ZIP contains an encrypted, oversized, or symbolic-link entry.")
        bad = zf.testzip()
        if bad: raise ValueError("ZIP integrity check failed at " + bad)
        manifest, files = _update_manifest_and_files(zf)
    if expected_version and str(manifest.get("version")) != str(expected_version):
        raise ValueError("Package version does not match the release feed version.")
    if state.get("active") and not state.get("finished"):
        raise ValueError("Finish the current competition before staging a server update.")
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    staged_manifest_path = UPDATE_DIR / "staged_manifest.json"
    try: staged_manifest_path.unlink()
    except FileNotFoundError: pass
    if STAGED_DIR.exists(): shutil.rmtree(STAGED_DIR)
    STAGED_DIR.mkdir(parents=True)
    for name, payload in files.items():
        target = (STAGED_DIR / name).resolve()
        if STAGED_DIR.resolve() not in target.parents: raise ValueError("Unsafe update path.")
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(target.name + ".part")
        temp.write_bytes(payload); os.replace(str(temp), str(target))
    safe_manifest = {"version": manifest["version"], "release_notes": str(manifest.get("release_notes", ""))[:2000], "files": list(files.keys()), "file_hashes": {name: hashlib.sha256(payload).hexdigest() for name, payload in files.items()}}
    temp_meta = staged_manifest_path.with_name("staged_manifest.json.part")
    temp_meta.write_text(json.dumps(safe_manifest, indent=2), encoding="utf-8")
    os.replace(str(temp_meta), str(staged_manifest_path))
    app.logger.info("Teacher staged server update %s (%d files)", manifest["version"], len(files))
    return safe_manifest

@app.get("/api/teacher/server-update/status")
@teacher_required
def server_update_status():
    staged = UPDATE_DIR / "staged_manifest.json"
    details = None
    if staged.exists():
        try: details = json.loads(staged.read_text(encoding="utf-8"))
        except (OSError, ValueError): details = {"version": "unknown"}
    worker_status = None
    worker_status_path = UPDATE_DIR / "worker_status.json"
    if worker_status_path.is_file():
        try:
            worker_status = json.loads(worker_status_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            worker_status = {"state": "unknown", "message": "Updater status file could not be read."}
    if details and _version_tuple(str(details.get("version", "0"))) <= _version_tuple(_current_app_version()):
        details = None
    backup_root = ROOT / "backups"
    history = []
    if backup_root.exists():
        for folder in sorted((p for p in backup_root.iterdir() if p.is_dir()), reverse=True)[:20]:
            journal = folder / "rollback_journal.json"
            try:
                item = json.loads(journal.read_text(encoding="utf-8"))
                history.append({"backup": folder.name, "version": item.get("version", "unknown"),
                                "from_version": item.get("old_version", "unknown"), "state": item.get("state", "unknown")})
            except (OSError, ValueError):
                history.append({"backup": folder.name, "version": "unknown", "from_version": "unknown", "state": "backup"})
    return jsonify(ok=True, current_version=_current_app_version(), staged=details, worker_status=worker_status, feed_url=_load_update_feed(), backups=[x["backup"] for x in history], version_history=history)

@app.post("/api/teacher/server-update/feed")
@teacher_required
def server_update_feed():
    data = request.get_json(silent=True) or {}; url = str(data.get("url", "")).strip()
    if url:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            return jsonify(ok=False, message="Enter a valid HTTPS update-feed URL."), 400
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    (UPDATE_DIR / "update_feed.json").write_text(json.dumps({"url": url}, indent=2), encoding="utf-8")
    return jsonify(ok=True, message="Update feed settings saved.", feed_url=url)

@app.post("/api/teacher/server-update/check")
@teacher_required
def server_update_check():
    url = _load_update_feed()
    if not url: return jsonify(ok=False, message="Configure an HTTPS update-feed URL first."), 400
    try:
        feed = _fetch_https_json(url)
        version = str(feed.get("version", "")).strip()
        package_url = str(feed.get("package_url", "")).strip()
        digest = str(feed.get("sha256", "")).lower()
        if not re.fullmatch(r"[0-9A-Za-z][0-9A-Za-z._+-]{0,39}", version): raise ValueError("Feed version is missing or invalid.")
        parsed = urllib.parse.urlparse(package_url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password: raise ValueError("Package URL must use HTTPS without embedded credentials.")
        if not re.fullmatch(r"[a-f0-9]{64}", digest): raise ValueError("Feed SHA-256 is missing or invalid.")
        available = _version_tuple(version) > _version_tuple(_current_app_version())
        return jsonify(ok=True, current_version=_current_app_version(), available=available, version=version, package_url=package_url, sha256=digest, release_notes=str(feed.get("release_notes", ""))[:2000], message=("A newer release is available." if available else "This server is already on the feed version."))
    except Exception as exc:
        app.logger.warning("Update feed check failed: %s", exc)
        return jsonify(ok=False, message="Update check failed: " + str(exc)), 502

@app.post("/api/teacher/server-update/download")
@teacher_required
def server_update_download():
    data = request.get_json(silent=True) or {}; package_url = str(data.get("package_url", "")).strip(); expected = str(data.get("sha256", "")).lower()
    parsed = urllib.parse.urlparse(package_url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or not re.fullmatch(r"[a-f0-9]{64}", expected):
        return jsonify(ok=False, message="Invalid package URL or SHA-256."), 400
    if state.get("active") and not state.get("finished"):
        return jsonify(ok=False, message="Finish the current competition before downloading and staging an update."), 409
    try:
        req = urllib.request.Request(package_url, headers={"User-Agent": "WOWBII-Updater/1.1"})
        with urllib.request.urlopen(req, timeout=30) as response:
            if urllib.parse.urlparse(response.geturl()).scheme != "https": raise ValueError("Package redirected away from HTTPS.")
            if response.status != 200: raise ValueError("Package server returned HTTP " + str(response.status))
            raw = response.read(UPDATE_MAX_BYTES + 1)
        if len(raw) > UPDATE_MAX_BYTES: raise ValueError("Update package exceeds the 25 MB limit.")
        if not hmac.compare_digest(hashlib.sha256(raw).hexdigest(), expected): raise ValueError("Downloaded package SHA-256 does not match the release feed.")
        staged = _stage_verified_update(raw, data.get("version"))
        return jsonify(ok=True, message="Update downloaded, verified and staged. Review the release notes, then approve installation in this dashboard.", version=staged["version"], release_notes=staged["release_notes"])
    except Exception as exc:
        app.logger.warning("Automatic update download failed: %s", exc)
        return jsonify(ok=False, message="Update download failed: " + str(exc)), 502

@app.post("/api/teacher/server-update/upload")
@teacher_required
def server_update_upload():
    upload = request.files.get("file")
    if not upload or not upload.filename or not upload.filename.lower().endswith(".zip"):
        return jsonify(ok=False, message="Choose a valid WOWBII update ZIP package."), 400
    try:
        staged = _stage_verified_update(upload.read(UPDATE_MAX_BYTES + 1))
        return jsonify(ok=True, message="Update verified and staged. Review the release notes, then approve installation in this dashboard.", version=staged["version"], files=staged["files"], release_notes=staged["release_notes"])
    except (zipfile.BadZipFile, ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        app.logger.warning("Rejected server update package: %s", exc)
        return jsonify(ok=False, message="Update rejected: " + str(exc)), 400

@app.post("/api/teacher/server-update/install")
@teacher_required
def server_update_install():
    if state.get("active") and not state.get("finished"):
        return jsonify(ok=False, message="Installation is blocked while a competition is active."), 409
    staged = UPDATE_DIR / "staged_manifest.json"
    if not staged.is_file():
        return jsonify(ok=False, message="There is no verified update waiting to install."), 404
    try:
        details = json.loads(staged.read_text(encoding="utf-8"))
        version = str(details.get("version", ""))
        if _version_tuple(version) <= _version_tuple(_current_app_version()):
            return jsonify(ok=False, message="The staged version is not newer than the installed version."), 409
        import subprocess, sys
        worker = ROOT / "updater_worker.py"
        if not worker.is_file():
            return jsonify(ok=False, message="The automatic installer worker is missing. Reinstall the full WOWBII project ZIP."), 500
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen([sys.executable, str(worker), "--pid", str(os.getpid()), "--root", str(ROOT)],
                         cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, close_fds=True, creationflags=flags)
        app.logger.warning("Teacher approved automatic installation of version %s; server is restarting", version)
        def stop_after_response():
            time.sleep(1.5)
            os._exit(0)
        threading.Thread(target=stop_after_response, daemon=True).start()
        return jsonify(ok=True, message="Installation approved. The server is shutting down; the installer will apply the verified update, then restart WOWBII.")
    except Exception as exc:
        app.logger.exception("Could not start automatic update installer")
        return jsonify(ok=False, message="Could not start the installer: " + str(exc)), 500


@app.get("/api/health")
def health():
    """Unauthenticated, read-only diagnostic endpoint for classroom connectivity checks."""
    try:
        with db_connect() as conn:
            conn.execute("SELECT 1").fetchone()
        database_ok = True
    except sqlite3.Error:
        database_ok = False
        app.logger.exception("Health check: database unavailable")
    with lock:
        connected = sum(1 for player in state["players"].values()
                        if time.time() - float(player.get("last_seen", 0) or 0) <= 35)
        active = bool(state.get("active"))
    return jsonify(ok=database_ok, service="WOWBII Quiz Server", database="ok" if database_ok else "error",
                   uptime_seconds=int(time.time()-SERVER_STARTED_AT), players_connected=connected,
                   players_limit=MAX_PLAYERS, competition_active=active, server_time=int(time.time())), (200 if database_ok else 503)

@app.post("/api/heartbeat")
def heartbeat():
    data = request.get_json(silent=True) or {}
    code = str(data.get("code", ""))[:80]
    with lock:
        player = state["players"].get(code)
        if not player:
            return jsonify(ok=False, resume_required=True, message="Pupil session not found. Ask the teacher to check the session."), 404
        player["last_seen"] = time.time()
    return jsonify(ok=True, server_time=int(time.time()))

@app.get("/api/status")
def status():
    code=request.args.get("code","")
    with lock:
        if code not in state["players"]: return jsonify(ok=False,message="Pupil session not found.")
        if state["players"][code].get("eliminated"): return jsonify(ok=False,message="You did not qualify for this stage."),403
        maybe_finish(); p=state["players"][code]; p["last_seen"] = time.time(); started=state["start"] is not None
        qs=assigned_questions(p)
        result={"ok":True,"started":started,"finished":state["finished"],"remaining":remaining(),
                "questions":[safe_question(q) for q in qs] if started else [],"answers":p["answers"],
                "mode":state["mode"],"competition":state["competition"],"team":p.get("team",""),"submitted":p["submitted"],"rapid_fire":state.get("rapid_fire",False),"lifelines":p.get("lifelines",{}),"eliminated_options":p.get("eliminated_options",{}),"double_points":p.get("double_points",[]),"show_mode":state.get("show_mode",True),"stage":(state.get("stages") or [{"name":"Practice Round"}])[state.get("stage_index",0)],"stage_index":state.get("stage_index",0),"stage_count":len(state.get("stages",[])),"round_type":state.get("round_type","standard"),"tournament_enabled":state.get("tournament_enabled",False),"selected_category":state.get("selected_category","")}
        if state["finished"]: result.update(score=score_player(p),total=len(qs),explanations=[q.get("explanation","") for q in qs])
        return jsonify(result)

@app.post("/api/progress")
def update_progress():
    d = request.get_json(silent=True) or {}
    code = str(d.get("code", ""))
    raw_index = d.get("index", 0)
    if isinstance(raw_index, bool):
        return jsonify(ok=False, message="Invalid question index."), 400
    try:
        index = int(raw_index)
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Invalid question index."), 400
    with lock:
        if code not in state["players"]:
            return jsonify(ok=False, message="Pupil session not found."), 404
        if state["start"] is None or state["finished"]:
            return jsonify(ok=False, message="Question progress is not active."), 409
        p = state["players"][code]
        qs = assigned_questions(p)
        if not qs:
            return jsonify(ok=False, message="No questions assigned."), 409
        index = max(0, min(index, len(qs) - 1))
        if p.get("current_index") != index:
            p["current_index"] = index
            persist_runtime_state()
    return jsonify(ok=True)


@app.post("/api/lifeline")
def use_lifeline():
    d=request.get_json(silent=True) or {}; code=str(d.get("code","")); kind=str(d.get("kind",""));
    with lock:
        if code not in state["players"] or state["start"] is None or state["finished"]:
            return jsonify(ok=False,message="Lifelines are unavailable."),409
        p=state["players"][code]
        if p.get("submitted"): return jsonify(ok=False,message="You have already submitted."),409
        try: index=int(d.get("index",p.get("current_index",0)))
        except (TypeError,ValueError): return jsonify(ok=False,message="Invalid question."),400
        qs=assigned_questions(p)
        if not 0 <= index < len(qs) or str(index) in p.get("answers",{}):
            return jsonify(ok=False,message="This question cannot use a lifeline."),409
        lifelines=p.setdefault("lifelines",{"fifty_fifty":1,"double_points":1})
        if not state.get("show_mode", True): return jsonify(ok=False,message="Tournament lifelines are disabled for this session."),409
        if kind=="fifty_fifty":
            if lifelines.get("fifty_fifty",0)<=0: return jsonify(ok=False,message="50:50 has already been used."),409
            correct=qs[index].get("answer")
            wrong=[i for i in range(4) if i!=correct]
            keep_wrong=random.choice(wrong)
            eliminated=[i for i in wrong if i!=keep_wrong]
            p.setdefault("eliminated_options",{})[str(index)]=eliminated
            lifelines["fifty_fifty"]=0
            result={"eliminated":eliminated,"message":"50:50 used. Two incorrect options have been removed."}
        elif kind=="double_points":
            if lifelines.get("double_points",0)<=0: return jsonify(ok=False,message="Double points has already been used."),409
            p.setdefault("double_points",[]).append(index); lifelines["double_points"]=0
            result={"message":"Double points activated for this question."}
        else: return jsonify(ok=False,message="Unknown lifeline."),400
        persist_runtime_state()
    socketio.emit("quiz_state_changed", {"event":"lifeline"})
    return jsonify(ok=True,**result,lifelines=lifelines)


@app.post("/api/answer")
def answer():
    d=request.get_json(silent=True) or {}; code=str(d.get("code",""))
    with lock:
        maybe_finish()
        if code not in state["players"] or state["players"].get(code,{}).get("eliminated") or state["finished"] or state["start"] is None: return jsonify(ok=False,message="Answers are closed.")
        if remaining()<=0: state["finished"]=True; return jsonify(ok=False,message="Time is up.")
        p=state["players"][code]
        if p["submitted"]: return jsonify(ok=False,message="You have already submitted.")
        qs=assigned_questions(p)
        try:
            if isinstance(d.get("index"), bool) or isinstance(d.get("answer"), bool):
                return jsonify(ok=False,message="Invalid answer.")
            i=int(d["index"]); a=int(d["answer"])
            if not (0<=i<len(qs) and 0<=a<4): return jsonify(ok=False,message="Invalid answer.")
            existing = p["answers"].get(str(i))
            if existing is not None:
                if int(existing) == a:
                    correct = (a == qs[i].get("answer"))
                    return jsonify(ok=True, correct=correct, score=score_player(p), duplicate=True)
                return jsonify(ok=False, message="An answer is already recorded for this question."), 409
            p["answers"][str(i)]=a
            p["last_seen"] = time.time()
            correct=(a==qs[i].get("answer"))
            persist_runtime_state()
        except Exception: return jsonify(ok=False,message="Invalid answer.")
    socketio.emit("quiz_state_changed", {"event":"answer"})
    return jsonify(ok=True,correct=correct,score=score_player(p))

@app.post("/api/submit")
def submit_answers():
    d=request.get_json(silent=True) or {}; code=str(d.get("code",""))
    with lock:
        if code not in state["players"]: return jsonify(ok=False,message="Pupil session not found.")
        if state["players"][code].get("eliminated"): return jsonify(ok=False,message="You did not qualify for this stage."),403
        maybe_finish()
        if state["start"] is None or state["finished"]:
            return jsonify(ok=False,message="Submission is closed because the competition has not started or has ended.")
        state["players"][code]["submitted"]=True
        persist_runtime_state()
    return jsonify(ok=True)

@app.get("/api/leaderboard")
def get_leaderboard():
    with lock:
        maybe_finish()
        return jsonify(rows=rows(),leaderboard=leaderboard(),finished=state["finished"],title=state["title"],
          started=state["start"] is not None,remaining=remaining(),mode=state["mode"],competition=state["competition"],
          question_count=state.get("question_count",len(state["questions"])),players_count=len(state["players"]),
          class_level=state["class_level"],subject=state["subject"],display_question=display_question(),
          current_questions=current_questions(),rapid_fire=state.get("rapid_fire",False),show_mode=state.get("show_mode",True),
          stage=(state.get("stages") or [{"name":"Practice Round"}])[state.get("stage_index",0)],stage_index=state.get("stage_index",0),stage_count=len(state.get("stages",[])),round_type=state.get("round_type","standard"),eliminated_count=len(state.get("eliminated_players",[])),selected_category=state.get("selected_category",""))

def current_questions():
    result = []
    for code, p in state["players"].items():
        qs = assigned_questions(p)
        if not qs:
            continue
        try:
            index = int(p.get("current_index", 0))
        except (TypeError, ValueError):
            index = 0
        index = max(0, min(index, len(qs) - 1))
        q = qs[index]
        result.append({
            "name": p.get("name", "Pupil"), "team": p.get("team", ""),
            "index": index, "total": len(qs), "question": q.get("question", ""),
            "options": q.get("options", []), "subject": q.get("subject", state["subject"]),
            "answered": len(p.get("answers", {})), "submitted": bool(p.get("submitted", False))
        })
    return result


def display_question():
    if state["mode"] != "same" or not state["questions"]: return None
    players=list(state["players"].values())
    index=0
    if players:
        for i in range(len(state["questions"])):
            if not all(str(i) in p.get("answers", {}) for p in players):
                index=i; break
            index=min(i+1,len(state["questions"])-1)
    q=state["questions"][index]
    return {"index":index,"total":len(state["questions"]),"question":q["question"],"options":q["options"],"subject":q.get("subject",""),"points":int(q.get("points",10) or 10)}

restore_runtime_state()

if __name__=="__main__":
    print("Teacher panel: http://127.0.0.1:5000/teacher")
    print("Smart-board display: http://127.0.0.1:5000/display")
    print("Student page: http://127.0.0.1:5000/")
    print("On other devices, open http://<SERVER-PC-IP>:5000/ (same school Wi-Fi).")
    print("Health check: http://127.0.0.1:5000/api/health")
    print(f"Server log: {LOG_FILE}")
    print(f"Teacher access PIN: {TEACHER_PIN}")
    print("Keep this teacher PIN private. It is stored locally in .teacher_pin.")
    socketio.run(app, host="0.0.0.0", port=5000, debug=False, allow_unsafe_werkzeug=True)
